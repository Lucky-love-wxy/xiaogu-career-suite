import fs from "node:fs/promises";
import { launchIndependent } from "/Users/lucky_wang/.agents/skills/web-access/scripts/playwright-runtime.mjs";

const target = "https://yeezytb.com/hypefade/";
const output = new URL("./hypefade-live.json", import.meta.url);
const sample = [
  "职位：电商运营",
  "薪资：15-25K",
  "职责：独立负责店铺运营，结果导向，能适应弹性工作。",
  "要求：有主人翁意识，抗压能力强，完成领导交办的其他任务。",
].join("\n");

let browser;
try {
  ({ browser } = await launchIndependent());
  const page = await browser.newPage();
  const requests = [];
  const responses = [];
  page.on("request", (request) => {
    const type = request.resourceType();
    if (["xhr", "fetch"].includes(type)) {
      requests.push({ method: request.method(), url: request.url(), type });
    }
  });
  page.on("response", (response) => {
    const request = response.request();
    if (["xhr", "fetch"].includes(request.resourceType())) {
      responses.push({ status: response.status(), url: response.url() });
    }
  });

  const navigation = await page.goto(target, { waitUntil: "domcontentloaded", timeout: 30000 });
  await page.waitForFunction(() => (document.body?.innerText || "").includes("招聘黑话翻译器"), null, { timeout: 15000 });

  const before = await page.evaluate(() => ({
    title: document.title,
    text: document.body.innerText,
    inputs: [...document.querySelectorAll("input, textarea")].map((element) => ({
      tag: element.tagName,
      type: element.getAttribute("type"),
      name: element.getAttribute("name"),
      placeholder: element.getAttribute("placeholder"),
      ariaLabel: element.getAttribute("aria-label"),
    })),
    buttons: [...document.querySelectorAll("button")].map((element) => element.innerText.trim()).filter(Boolean),
    scripts: [...document.scripts].map((element) => element.src).filter(Boolean),
    stylesheets: [...document.querySelectorAll('link[rel="stylesheet"]')].map((element) => element.href),
    localStorageKeys: Object.keys(localStorage),
  }));

  const textarea = page.locator("textarea").first();
  await textarea.fill(sample);
  const startButton = page.getByRole("button", { name: /开始挥发翻译/ });
  await startButton.click();
  await page.waitForTimeout(4000);

  const after = await page.evaluate(() => ({
    text: document.body.innerText,
    headings: [...document.querySelectorAll("h1,h2,h3,h4")].map((element) => element.innerText.trim()).filter(Boolean),
    dialogs: [...document.querySelectorAll('[role="dialog"]')].map((element) => element.innerText.trim()),
    localStorage: Object.fromEntries(Object.keys(localStorage).map((key) => [key, localStorage.getItem(key)])),
  }));

  const result = {
    inspectedAt: new Date().toISOString(),
    target,
    status: navigation?.status(),
    sample,
    before,
    after,
    requests,
    responses,
  };
  await fs.writeFile(output, JSON.stringify(result, null, 2));
  console.log(JSON.stringify({
    status: result.status,
    title: before.title,
    inputCount: before.inputs.length,
    buttonCount: before.buttons.length,
    scriptCount: before.scripts.length,
    xhrCount: requests.length,
    outputCharacters: after.text.length,
    output: output.pathname,
  }));
} finally {
  if (browser) await browser.close();
}
