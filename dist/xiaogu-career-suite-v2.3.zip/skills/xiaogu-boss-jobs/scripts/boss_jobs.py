#!/usr/bin/env python3
from pathlib import Path
import runpy

runpy.run_path(str(Path(__file__).resolve().parents[2] / "_xiaogu-runtime" / "scripts" / "boss_jobs.py"), run_name="__main__")
