$(document).ready(function() {
    if ($('#wrapper').attr('data-type') == 'list') {
        var list_url = document.location.href;
        var list_number = list_url.match(/.+\/(\d+)/);
        list_number ? list_number = list_number[1] : null;

        if (list_number == '21' || list_number == '22' || list_number == '23') {
            $('#header .menu ul li').eq(0).find('a').removeAttr('target').click(function() {
                alert('这部分没有指标解释！');
            });
        } else {
            $('#header .menu ul li').eq(0).find('a').attr('href', list_number + '/indicators.html')
        }

        document.title = $('#list .left h2').text() + ' - ' + document.title;
    }
    /*list*/

    if ($('#wrapper').attr('data-type') == 'table') {
        var url = document.location.href;
        var table_number = url.match(/.+\/(.+)\./);
        table_number ? table_number = table_number[1] : null;

        var table_directory = table_number.split('-');
        table_directory ? table_directory = table_directory[0] : null;

        $('#header .menu ul li').eq(0).find('a').attr('href', '../excel/' + table_number + '.xlsx');
        $('#header .menu ul li').eq(2).find('a').attr('href', '../../' + table_directory + '.html');

        $('.btn-go-back').attr('href', '../../' + table_directory + '.html');

        if (table_directory == '21' || table_directory == '22' || table_directory == '23') {
            $('#header .menu ul li').eq(1).find('a').removeAttr('target').click(function() {
                alert('这部分没有指标解释！');
            });
        } else {
            $('#header .menu ul li').eq(1).find('a').attr('href', '../indicators.html');
        }

        document.title = $('table').find('td').eq(0).text() + ' - ' + document.title;
    }
    /*table*/

    if ($('#wrapper').attr('data-type') == 'container') {
        var paging = $('#container .tab');
        for (var i = 1; i <= paging.length; i++) {
        $('#container .paging').append('<a data-paging="' + i + '" title="' + i + '" href="javascript:">' + i + '</a>');
        };
        $('#container .paging a').on('click', function() {
            $('#container .paging a').removeClass('visited');
            $(this).addClass('visited');
            var i = $(this).data('paging');
            var j = i - 1;
            paging.hide();
            paging.eq(j).show();
            window.scrollTo(0,0);
        });
        $('#container .paging a').eq(0).click();
    }
    /*container*/

    $('.btn-close').click(function() {
        window.opener = null;
        window.close();
    });

    $('.btn-text').click(function() {
        alert('@(C)中国统计出版社     版权所有。未经许可，本书的任何部分不准以任何形式在世界任何地区以任何形式重印、拷贝、仿制或转载本书图版和文字之一部分或全部。CD-ROM 中的所有数据均以《东莞统计年鉴-2025》书中内容为准。          @ Copyright (C) China Statistics Press. All rights reserved. No part of the publication may be reproduced or transmitted in any form or by any means,electronic or mechanical,including photocopying,rec ording,or any information storage and retrieval system,without written permission from the publisher. If there is some difference between the data in CD-ROM and those in book, please refer to the data in Dongguan Statistical Yearbook -2025.')
    });
    
    $('[class*="back-top"]').click(function() {
        $('html, body').animate({ 'scrollTop': 0 }, 300);
    });

    $(window).scroll(function() {
        if ($(document).scrollTop() > 100) {
            $('.btn-back-top').css('display', 'block');
        } else {
            $('.btn-back-top').css('display', 'none');
        }
    })
    /*toolkit*/
});